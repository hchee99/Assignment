using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSkill : MonoBehaviour
{
    private Animator animator;
    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            animator.SetTrigger("Skill_Q");
        }
        else if (Input.GetKeyDown(KeyCode.W))
        {
            animator.SetTrigger("Skill_W");
        }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            animator.SetTrigger("Skill_E");
        }
    }
}
